---
layout: page
title: Category
permalink: /category/
exclude_from_nav: true
---

<img src="https://avatars2.githubusercontent.com/u/8794792?v=3&s=180">

<br>
Spaghetti-san a.k.a. Axl Yody


I am Axl, a UI Designer, Front End Developer, Illustrator, and of course Anime and Visual Novel lovers from Indonesian.
Living in Jakarta, and studied at Bina Sarana Informatika.
I love my work and enjoy each new project as I get it.
By the way i'm just a freelance and work a project from home with only laptop and figurine beside my laptop.



Feel free to contact me on [Facebook](https://www.facebook.com/profile.php?id=100007594726461), don't be hesitate to ask, also you can add me :))



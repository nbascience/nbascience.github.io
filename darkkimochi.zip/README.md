# spaghetti.ga
Based of Jekyll default theme and redesign again by me.<br>
Feel free to use this theme :^)
<br><br>
But please don't try to copy anything from my article :p


# License
MIT
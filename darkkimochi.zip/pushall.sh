#!/bin/bash


gulp comments && git add --all && git commit -m "..." && git push 